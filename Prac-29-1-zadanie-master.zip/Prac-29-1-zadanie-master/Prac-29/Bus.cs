﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Bus
{
    private string brand;
    private int seats;
    private decimal ticketPrice;

    public string Brand
    {
        get 
        { 
            return brand; 
        }
        set
        {
            if (string.IsNullOrEmpty(value))
                throw new ArgumentException("Марка не указана");
            brand = value;
        }
    }

    public int Seats
    {
        get 
        {
            return seats; 
        }
        set
        {
            if (value <= 0)
                throw new ArgumentException("Количество мест должно быть положительным");
            seats = value;
        }
    }

    public decimal TicketPrice
    {
        get { return ticketPrice; }
        set
        {
            if (value < 0)
                throw new ArgumentException("Стоимость билета не может быть отрицательной");
            ticketPrice = value;
        }
    }

    public Bus(string brand, int seats, decimal ticketPrice)
    {
        Brand = brand;
        Seats = seats;
        TicketPrice = ticketPrice;
    }

    public virtual decimal TotalCost()
    {
        return Seats * TicketPrice;
    }

    public virtual void DisplayInfo()
    {
        Console.WriteLine($"Автобус: {Brand}");
        Console.WriteLine($"Количество мест: {Seats}");
        Console.WriteLine($"Цена билета: {TicketPrice:C}");
        Console.WriteLine($"Общая стоимость: {TotalCost():C}");
    }
}