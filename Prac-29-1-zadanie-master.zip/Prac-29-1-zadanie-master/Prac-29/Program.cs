﻿using System;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            Bus regularBus = new Bus("Volvo", 40, 1500.50m);
            Console.WriteLine("Информация об обычном автобусе:");
            regularBus.DisplayInfo();

            Console.WriteLine("\n------------------------\n");

            TourBus tourBus = new TourBus("Mercedes", 30, 2000.00m, 1500.00m);
            Console.WriteLine("Информация о туристическом автобусе:");
            tourBus.DisplayInfo();
        }

        catch (ArgumentException ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
        Console.Read();
    }
}

