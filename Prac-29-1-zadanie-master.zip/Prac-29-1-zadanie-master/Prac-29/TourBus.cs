﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class TourBus : Bus
{
    private decimal tourCost;

    public decimal TourCost
    {
        get
        { 
            return tourCost; 
        }
        set
        {
            if (value < 0)
                throw new ArgumentException("Стоимость экскурсии должна быть положительной");
            tourCost = value;
        }
    }

    public TourBus(string brand, int seats, decimal ticketPrice, decimal tourCost)
        : base(brand, seats, ticketPrice)
    {
        TourCost = tourCost;
    }

    public override decimal TotalCost()
    {
        return Seats * (TicketPrice + TourCost);
    }

    public override void DisplayInfo()
    {
        Console.WriteLine($"Туристический автобус: {Brand}");
        Console.WriteLine($"Количество мест: {Seats}");
        Console.WriteLine($"Цена билета: {TicketPrice:C}");
        Console.WriteLine($"Стоимость экскурсии: {TourCost:C}");
        Console.WriteLine($"Общая стоимость: {TotalCost():C}");
    }
}