﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac_29_zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Press press = new Press("Стандартный пресс", 1000, 5.0);
            Console.WriteLine("Состояние объекта базового класса:");
            press.Output();
            Console.WriteLine();

            Magazine magazine = new Magazine("Модный журнал", 500, 10.0, "Высокое");
            Console.WriteLine("Состояние объекта производного класса:");
            magazine.Output();
            Console.WriteLine();

            Press pressRef = magazine;
            Console.WriteLine("Состояние объекта через ссылку базового класса:");
            pressRef.Output();

            Console.ReadKey();
        }
    }
}
