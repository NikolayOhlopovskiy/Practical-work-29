﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac_29_zadanie_2
{
    class Magazine : Press
    {
        public string PaperQuality { get; set; }

        public Magazine(string name, int copies, double price, string paperQuality)
            : base(name, copies, price)
        {
            PaperQuality = paperQuality;
        }

        public override double Cost()
        {
            double baseCost = base.Cost();
            
            if (baseCost > 1000) 
                return baseCost * 1.10;
            else if (baseCost < 500)
                return baseCost * 0.90;
            else 
                return baseCost;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($"Качество бумаги: {PaperQuality}");
        }
    }
}
