﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Press
{

    public string Name { get; set; }
    public int Copies { get; set; }
    public double Price { get; set; }


    public Press(string name, int copies, double price)
    {
        Name = name;
        Copies = copies;
        Price = price;
    }


    public virtual double Cost()
    {
        return Copies * Price;
    }

    public virtual void Output()
    {
        Console.WriteLine($"Название: {Name}");
        Console.WriteLine($"Тираж: {Copies}");
        Console.WriteLine($"Цена за экземпляр: {Price}");
        Console.WriteLine($"Стоимость тиража: {Cost()}");
    }
}
